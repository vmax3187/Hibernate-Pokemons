package main.java;


import main.java.carga.CargaDatos;
import main.java.com.hibernate.persistencia.ServicioPersistenciaEpisodio;
import main.java.com.hibernate.persistencia.ServicioPersistenciaPersonaje;
import main.java.com.hibernate.persistencia.ServicioPersistenciaUbicacion;
import main.java.model.Episodio;
import main.java.model.Personaje;
import main.java.model.Ubicacion;

public class Principal {

    public static void main(String[] args) throws Exception {

        // ── 1. Carga inicial desde la API ────────────────────────────────────
        // ⚠ Ejecutar solo una vez. Comentar estas dos líneas si los datos
        //   ya están en la BD para evitar errores de clave duplicada.
        System.out.println("=== CARGA DE DATOS DESDE LA API ===");
        new CargaDatos().cargarTodo();

        // ── 2. CRUD de prueba ────────────────────────────────────────────────
        ServicioPersistenciaPersonaje  svcPersonaje  = new ServicioPersistenciaPersonaje();
        ServicioPersistenciaEpisodio   svcEpisodio   = new ServicioPersistenciaEpisodio();
        ServicioPersistenciaUbicacion  svcUbicacion  = new ServicioPersistenciaUbicacion();

        // --- Personaje ---
        System.out.println("\n=== CRUD PERSONAJE ===");
        Personaje homer = svcPersonaje.obtener(1L);
        System.out.println("Obtenido: " + homer);

        if (homer != null) {
            homer.setOccupation("trabaja en una central nuclear");
            svcPersonaje.actualizar(homer);
        }

        System.out.println("Personaje inexistente:");
        svcPersonaje.obtener(9999L);
        System.out.println("El programa continúa correctamente.");

        // --- Episodio ---
        System.out.println("\n=== CRUD EPISODIO ===");
        Episodio ep = svcEpisodio.obtener(1L);
        System.out.println("Obtenido: " + ep);

        if (ep != null) {
            ep.setSynopsis("El episodio piloto de Los Simpson.");
            svcEpisodio.actualizar(ep);
        }

        // --- Ubicación ---
        System.out.println("\n=== CRUD UBICACIÓN ===");
        Ubicacion u = svcUbicacion.obtener(1L);
        System.out.println("Obtenida: " + u);

        if (u != null) {
            u.setTown("Springfield");
            svcUbicacion.actualizar(u);
        }

        System.out.println("\n=== FIN ===");
    }
}
