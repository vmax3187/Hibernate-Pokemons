package main.java.api;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.List;

/**
 * Cliente HTTP para la API REST de Los Simpson (https://thesimpsonsapi.com/api).
 *
 * Endpoints disponibles:
 *   characters → https://thesimpsonsapi.com/api/characters
 *   episodes   → https://thesimpsonsapi.com/api/episodes
 *   locations  → https://thesimpsonsapi.com/api/locations
 *
 * La API devuelve los resultados paginados (20 por página):
 *   { "count": N, "next": "url_siguiente_o_null", "results": [...] }
 */
public class ApiClient {

    private static final String BASE_URL = "https://thesimpsonsapi.com/api";

    // ── Constantes de endpoint ───────────────────────────────────────────────
    public static final String ENDPOINT_CHARACTERS = "characters";
    public static final String ENDPOINT_EPISODES   = "episodes";
    public static final String ENDPOINT_LOCATIONS  = "locations";

    private final HttpClient   httpClient = HttpClient.newHttpClient();
    private final ObjectMapper mapper     = new ObjectMapper();

    // ── Métodos de conveniencia por entidad ──────────────────────────────────

    /** Devuelve todos los personajes (recorre todas las páginas). */
    public List<JsonNode> getAllCharacters() throws Exception {
        return getAll(ENDPOINT_CHARACTERS);
    }

    /** Devuelve todos los episodios (recorre todas las páginas). */
    public List<JsonNode> getAllEpisodes() throws Exception {
        return getAll(ENDPOINT_EPISODES);
    }

    /** Devuelve todas las localizaciones (recorre todas las páginas). */
    public List<JsonNode> getAllLocations() throws Exception {
        return getAll(ENDPOINT_LOCATIONS);
    }

    /** Detalle de un personaje por id. */
    public JsonNode getCharacter(long id) throws Exception {
        return getOne(ENDPOINT_CHARACTERS, id);
    }

    /** Detalle de un episodio por id. */
    public JsonNode getEpisode(long id) throws Exception {
        return getOne(ENDPOINT_EPISODES, id);
    }

    /** Detalle de una localización por id. */
    public JsonNode getLocation(long id) throws Exception {
        return getOne(ENDPOINT_LOCATIONS, id);
    }

    // ── Métodos genéricos (paginación + detalle) ─────────────────────────────

    /**
     * Recorre TODAS las páginas de un endpoint y devuelve la lista completa.
     * Funciona con "characters", "episodes" y "locations".
     */
    public List<JsonNode> getAll(String endpoint) throws Exception {
        List<JsonNode> resultados = new ArrayList<>();
        String url = BASE_URL + "/" + endpoint;

        while (url != null) {
            JsonNode root = get(url);
            for (JsonNode item : root.get("results")) {
                resultados.add(item);
            }
            // "next" es null cuando es la última página
            JsonNode next = root.get("next");
            url = (next != null && !next.isNull()) ? next.asText() : null;
        }
        return resultados;
    }

    /** Obtiene el detalle de un elemento: /{endpoint}/{id} */
    public JsonNode getOne(String endpoint, long id) throws Exception {
        return get(BASE_URL + "/" + endpoint + "/" + id);
    }

    private JsonNode get(String url) throws Exception {
        HttpRequest request = HttpRequest.newBuilder(URI.create(url)).GET().build();
        HttpResponse<String> resp = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

        if (resp.statusCode() != 200) {
            throw new RuntimeException("Error HTTP " + resp.statusCode() + " al llamar: " + url);
        }

        return mapper.readTree(resp.body());
    }

    // ── Helpers para leer campos del JSON sin NullPointerException ────────────

    public static String texto(JsonNode n, String campo) {
        JsonNode v = n.get(campo);
        if (v == null || v.isNull()) return null;
        String s = v.asText();
        return s.isBlank() ? null : s;
    }

    public static Integer entero(JsonNode n, String campo) {
        JsonNode v = n.get(campo);
        return (v == null || v.isNull()) ? null : v.asInt();
    }

    public static Long longVal(JsonNode n, String campo) {
        JsonNode v = n.get(campo);
        return (v == null || v.isNull()) ? null : v.asLong();
    }
}
