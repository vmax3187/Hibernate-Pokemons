package main.java.com.hibernate.persistencia;

import main.java.com.hibernate.ConnectionUtil;
import main.java.model.Episodio;
import org.hibernate.Session;

import java.util.List;

public class ServicioPersistenciaEpisodio {

    public void persistir(Episodio episodio) {
        try {
            Session session = ConnectionUtil.getSessionFactory().openSession();
            session.beginTransaction();
            session.persist(episodio);
            session.getTransaction().commit();
            session.close();
            System.out.println("Episodio guardado: " + episodio);
        } catch (Exception e) {
            System.out.println("Error al guardar episodio: " + e.getMessage());
        }
    }

    public Episodio obtener(long id) {
        try {
            Session session = ConnectionUtil.getSessionFactory().openSession();
            Episodio ep = session.find(Episodio.class, id);
            session.close();
            if (ep == null) System.out.println("No se encontró el episodio con id=" + id);
            return ep;
        } catch (Exception e) {
            System.out.println("Error al obtener episodio id=" + id + ": " + e.getMessage());
            return null;
        }
    }

    public List<Episodio> obtenerTodos() {
        try {
            Session session = ConnectionUtil.getSessionFactory().openSession();
            // Nombre de entidad según @Entity(name = "Episodio")
            List<Episodio> lista = session.createQuery("from Episodio", Episodio.class).list();
            session.close();
            return lista;
        } catch (Exception e) {
            System.out.println("Error al obtener todos los episodios: " + e.getMessage());
            return List.of();
        }
    }

    public void actualizar(Episodio episodio) {
        try {
            Session session = ConnectionUtil.getSessionFactory().openSession();
            session.beginTransaction();
            session.merge(episodio);
            session.getTransaction().commit();
            session.close();
            System.out.println("Episodio actualizado: " + episodio);
        } catch (Exception e) {
            System.out.println("Error al actualizar episodio: " + e.getMessage());
        }
    }

    public void eliminar(long id) {
        try {
            Session session = ConnectionUtil.getSessionFactory().openSession();
            session.beginTransaction();
            Episodio ep = session.find(Episodio.class, id);
            if (ep == null) {
                System.out.println("No se encontró el episodio con id=" + id);
                session.close();
                return;
            }
            session.remove(ep);
            session.getTransaction().commit();
            session.close();
            System.out.println("Episodio eliminado con id=" + id);
        } catch (Exception e) {
            System.out.println("Error al eliminar episodio id=" + id + ": " + e.getMessage());
        }
    }
}
