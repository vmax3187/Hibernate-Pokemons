package main.java.com.hibernate.persistencia;

import main.java.com.hibernate.ConnectionUtil;
import main.java.model.Personaje;
import org.hibernate.Session;

import java.util.List;

public class ServicioPersistenciaPersonaje {

    public void persistir(Personaje personaje) {
        try {
            Session session = ConnectionUtil.getSessionFactory().openSession();
            session.beginTransaction();
            session.persist(personaje);
            session.getTransaction().commit();
            session.close();
            System.out.println("Personaje guardado: " + personaje);
        } catch (Exception e) {
            System.out.println("Error al guardar personaje: " + e.getMessage());
        }
    }

    public Personaje obtener(long id) {
        try {
            Session session = ConnectionUtil.getSessionFactory().openSession();
            Personaje p = session.find(Personaje.class, id);
            session.close();
            if (p == null) System.out.println("No se encontró el personaje con id=" + id);
            return p;
        } catch (Exception e) {
            System.out.println("Error al obtener personaje id=" + id + ": " + e.getMessage());
            return null;
        }
    }

    public List<Personaje> obtenerTodos() {
        try {
            Session session = ConnectionUtil.getSessionFactory().openSession();
            // Nombre de entidad según @Entity(name = "Personaje")
            List<Personaje> lista = session.createQuery("from Personaje", Personaje.class).list();
            session.close();
            return lista;
        } catch (Exception e) {
            System.out.println("Error al obtener todos los personajes: " + e.getMessage());
            return List.of();
        }
    }

    public void actualizar(Personaje personaje) {
        try {
            Session session = ConnectionUtil.getSessionFactory().openSession();
            session.beginTransaction();
            session.merge(personaje);
            session.getTransaction().commit();
            session.close();
            System.out.println("Personaje actualizado: " + personaje);
        } catch (Exception e) {
            System.out.println("Error al actualizar personaje: " + e.getMessage());
        }
    }

    public void eliminar(long id) {
        try {
            Session session = ConnectionUtil.getSessionFactory().openSession();
            session.beginTransaction();
            Personaje p = session.find(Personaje.class, id);
            if (p == null) {
                System.out.println("No se encontró el personaje con id=" + id);
                session.close();
                return;
            }
            session.remove(p);
            session.getTransaction().commit();
            session.close();
            System.out.println("Personaje eliminado con id=" + id);
        } catch (Exception e) {
            System.out.println("Error al eliminar personaje id=" + id + ": " + e.getMessage());
        }
    }
}
