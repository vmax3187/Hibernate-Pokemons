package main.java.com.hibernate.persistencia;

import main.java.com.hibernate.ConnectionUtil;
import main.java.model.Ubicacion;
import org.hibernate.Session;

import java.util.List;

public class ServicioPersistenciaUbicacion {

    public void persistir(Ubicacion ubicacion) {
        try {
            Session session = ConnectionUtil.getSessionFactory().openSession();
            session.beginTransaction();
            session.persist(ubicacion);
            session.getTransaction().commit();
            session.close();
            System.out.println("Ubicación guardada: " + ubicacion);
        } catch (Exception e) {
            System.out.println("Error al guardar ubicación: " + e.getMessage());
        }
    }

    public Ubicacion obtener(long id) {
        try {
            Session session = ConnectionUtil.getSessionFactory().openSession();
            Ubicacion u = session.find(Ubicacion.class, id);
            session.close();
            if (u == null) System.out.println("No se encontró la ubicación con id=" + id);
            return u;
        } catch (Exception e) {
            System.out.println("Error al obtener ubicación id=" + id + ": " + e.getMessage());
            return null;
        }
    }

    public List<Ubicacion> obtenerTodas() {
        try {
            Session session = ConnectionUtil.getSessionFactory().openSession();
            // Nombre de entidad según @Entity(name = "ubicacion")
            List<Ubicacion> lista = session.createQuery("from ubicacion", Ubicacion.class).list();
            session.close();
            return lista;
        } catch (Exception e) {
            System.out.println("Error al obtener todas las ubicaciones: " + e.getMessage());
            return List.of();
        }
    }

    public void actualizar(Ubicacion ubicacion) {
        try {
            Session session = ConnectionUtil.getSessionFactory().openSession();
            session.beginTransaction();
            session.merge(ubicacion);
            session.getTransaction().commit();
            session.close();
            System.out.println("Ubicación actualizada: " + ubicacion);
        } catch (Exception e) {
            System.out.println("Error al actualizar ubicación: " + e.getMessage());
        }
    }

    public void eliminar(long id) {
        try {
            Session session = ConnectionUtil.getSessionFactory().openSession();
            session.beginTransaction();
            Ubicacion u = session.find(Ubicacion.class, id);
            if (u == null) {
                System.out.println("No se encontró la ubicación con id=" + id);
                session.close();
                return;
            }
            session.remove(u);
            session.getTransaction().commit();
            session.close();
            System.out.println("Ubicación eliminada con id=" + id);
        } catch (Exception e) {
            System.out.println("Error al eliminar ubicación id=" + id + ": " + e.getMessage());
        }
    }
}
