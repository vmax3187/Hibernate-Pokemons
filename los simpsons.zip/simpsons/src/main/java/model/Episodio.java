package main.java.model;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity(name = "Episodio")
@Table(name = "episodios")
public class Episodio {

    public static final String URL_API = "https://thesimpsonsapi.com/api/episodes/";

    @Id
    private Long id;

    @Column
    private String name;

    @Column
    private Integer season;

    @Column(name = "episode_number")
    private Integer episodeNumber;

    @Column
    private LocalDate airdate;

    @Column(length = 2000)
    private String synopsis;

    @Column(name = "image_path")
    private String imagePath;

    // ── Getters y setters ────────────────────────────────────────────────────

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public Integer getSeason() { return season; }
    public void setSeason(Integer season) { this.season = season; }

    public Integer getEpisodeNumber() { return episodeNumber; }
    public void setEpisodeNumber(Integer episodeNumber) { this.episodeNumber = episodeNumber; }

    public LocalDate getAirdate() { return airdate; }
    public void setAirdate(LocalDate airdate) { this.airdate = airdate; }

    public String getSynopsis() { return synopsis; }
    public void setSynopsis(String synopsis) { this.synopsis = synopsis; }

    public String getImagePath() { return imagePath; }
    public void setImagePath(String imagePath) { this.imagePath = imagePath; }

    @Override
    public String toString() {
        return "Episodio[id=" + id + ", name=" + name + ", season=" + season + "]";
    }
}
