package main.java.model;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Entity(name = "Personaje")
@Table(name = "personajes")
public class Personaje {

    public static final String URL_API = "https://thesimpsonsapi.com/api/characters/";

    @Id
    private Long id;

    @Column
    private String name;

    @Column
    private Integer age;

    @Column
    private LocalDate birthdate;

    @Column
    private String gender;

    @Column
    private String occupation;

    @Column
    private String status;

    @Column(name = "portrait_path")
    private String portraitPath;

    /** Lista de frases del personaje almacenadas en tabla auxiliar */
    @ElementCollection(fetch = FetchType.LAZY)
    @CollectionTable(name = "personaje_frases", joinColumns = @JoinColumn(name = "personaje_id"))
    @Column(name = "frase", length = 1000)
    private List<String> phrases = new ArrayList<>();

    /** Primera aparición en un episodio */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "primera_aparicion_ep_id")
    private Episodio primeraAparicion;

    /** Episodios en los que aparece (N:M) */
    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(
        name = "personaje_episodios",
        joinColumns = @JoinColumn(name = "personaje_id"),
        inverseJoinColumns = @JoinColumn(name = "episodio_id")
    )
    private Set<Episodio> episodios = new HashSet<>();

    /** Ubicaciones donde reside (lado inverso de Ubicacion.residentes) */
    @ManyToMany(mappedBy = "residentes", fetch = FetchType.LAZY)
    private Set<Ubicacion> ubicaciones = new HashSet<>();

    // ── Helpers de negocio ───────────────────────────────────────────────────

    public void agregarEpisodio(Episodio ep) {
        episodios.add(ep);
    }

    // ── Getters y setters ────────────────────────────────────────────────────

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public Integer getAge() { return age; }
    public void setAge(Integer age) { this.age = age; }

    public LocalDate getBirthdate() { return birthdate; }
    public void setBirthdate(LocalDate birthdate) { this.birthdate = birthdate; }

    public String getGender() { return gender; }
    public void setGender(String gender) { this.gender = gender; }

    public String getOccupation() { return occupation; }
    public void setOccupation(String occupation) { this.occupation = occupation; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getPortraitPath() { return portraitPath; }
    public void setPortraitPath(String portraitPath) { this.portraitPath = portraitPath; }

    public List<String> getPhrases() { return phrases; }
    public void setPhrases(List<String> phrases) { this.phrases = phrases; }

    public Episodio getPrimeraAparicion() { return primeraAparicion; }
    public void setPrimeraAparicion(Episodio primeraAparicion) { this.primeraAparicion = primeraAparicion; }

    public Set<Episodio> getEpisodios() { return episodios; }
    public void setEpisodios(Set<Episodio> episodios) { this.episodios = episodios; }

    public Set<Ubicacion> getUbicaciones() { return ubicaciones; }
    public void setUbicaciones(Set<Ubicacion> ubicaciones) { this.ubicaciones = ubicaciones; }

    @Override
    public String toString() {
        return "Personaje[id=" + id + ", name=" + name + ", status=" + status + "]";
    }
}
